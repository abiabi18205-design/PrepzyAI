// Review status types
export type ReviewStatus = 'pending' | 'approved' | 'rejected';

// User role types for reviews
export type ReviewerRole = 'Student' | 'Graduate' | 'Developer' | 'Senior Developer' | 'Tech Lead' | 'Other';

// Main Review interface
export interface Review {
  _id: string;
  userId?: string;
  sessionId: string;
  name: string;
  email: string;
  role: ReviewerRole;
  company?: string;
  rating: number;
  message: string;
  imageUrl?: string | null;
  status: ReviewStatus;
  ipAddress?: string;
  reviewedAt?: Date;
  createdAt: string;
  updatedAt: string;
}

// Create review request payload
export interface CreateReviewData {
  sessionId: string;
  rating: number;
  message: string;
  role?: ReviewerRole;
  company?: string;
  name?: string;
  imageUrl?: string;
}

// Update review status request
export interface UpdateReviewStatusData {
  status: ReviewStatus;
}

// Review statistics
export interface ReviewStats {
  averageRating: number;
  totalReviews: number;
  ratingDistribution: {
    1: number;
    2: number;
    3: number;
    4: number;
    5: number;
  };
}

// Admin review counts
export interface ReviewCounts {
  total: number;
  pending: number;
  approved: number;
  rejected: number;
}

// API Response wrapper
export interface ReviewsApiResponse {
  success: boolean;
  message: string;
  data: {
    reviews: Review[];
    stats?: ReviewStats;
    counts?: ReviewCounts;
  };
  pagination?: {
    total: number;
    page: number;
    limit: number;
    totalPages: number;
  };
}

// Single review API response
export interface ReviewApiResponse {
  success: boolean;
  message: string;
  data: {
    review: Review;
  };
}

// Create review API response
export interface CreateReviewApiResponse {
  success: boolean;
  message: string;
  data: {
    review: {
      id: string;
      rating: number;
      status: ReviewStatus;
    };
  };
}

// Query params for fetching reviews
export interface GetReviewsQuery {
  status?: ReviewStatus | 'all';
  page?: number;
  limit?: number;
  sortBy?: 'createdAt' | 'rating';
  sortOrder?: 'asc' | 'desc';
}

// Query params for approved reviews (landing page)
export interface GetApprovedReviewsQuery {
  page?: number;
  limit?: number;
}

// Form data for review modal
export interface ReviewFormData {
  rating: number;
  message: string;
  role: ReviewerRole;
  company: string;
  name: string;
}

// Validation errors for review form
export interface ReviewFormErrors {
  rating?: string;
  message?: string;
  role?: string;
  name?: string;
}

// Props for ReviewModal component
export interface ReviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  sessionId: string;
  onSubmitSuccess?: () => void;
}

// Props for StarRating component
export interface StarRatingProps {
  rating: number;
  onRatingChange?: (rating: number) => void;
  readonly?: boolean;
  size?: number;
  showLabel?: boolean;
  label?: string;
}

// Props for Testimonials component
export interface TestimonialsProps {
  title?: string;
  subtitle?: string;
  limit?: number;
  showStats?: boolean;
}

// Props for AdminReviews component
export interface AdminReviewsProps {
  initialStatus?: ReviewStatus | 'all';
  itemsPerPage?: number;
}

// Review card component props
export interface ReviewCardProps {
  review: Review;
  showFullMessage?: boolean;
  onStatusChange?: (reviewId: string, status: ReviewStatus) => void;
  onDelete?: (reviewId: string) => void;
  isAdmin?: boolean;
}

// Helper type for rating distribution chart
export interface RatingDistributionData {
  rating: number;
  count: number;
  percentage: number;
}

// Helper function to get rating label
export const getRatingLabel = (rating: number): string => {
  switch (rating) {
    case 1:
      return 'Poor';
    case 2:
      return 'Fair';
    case 3:
      return 'Good';
    case 4:
      return 'Very Good';
    case 5:
      return 'Excellent';
    default:
      return 'Not rated';
  }
};

// Helper function to get rating color
export const getRatingColor = (rating: number): string => {
  switch (rating) {
    case 1:
      return 'text-red-500';
    case 2:
      return 'text-orange-500';
    case 3:
      return 'text-yellow-500';
    case 4:
      return 'text-blue-500';
    case 5:
      return 'text-green-500';
    default:
      return 'text-gray-500';
  }
};

// Helper function to validate review message length
export const isValidReviewMessage = (message: string): boolean => {
  const trimmed = message.trim();
  return trimmed.length >= 10 && trimmed.length <= 500;
};

// Helper function to get validation error message
export const getReviewValidationError = (message: string): string | null => {
  const trimmed = message.trim();
  if (trimmed.length < 10) {
    return 'Review must be at least 10 characters';
  }
  if (trimmed.length > 500) {
    return 'Review must be less than 500 characters';
  }
  return null;
};