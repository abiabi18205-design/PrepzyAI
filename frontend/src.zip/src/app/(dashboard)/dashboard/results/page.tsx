// app/(dashboard)/dashboard/results/page.tsx
"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import api from "@/lib/api";
import ReviewModal from "@/components/reviews/ReviewModal";
import {
  ChartBarIcon,
  ClockIcon,
  TrophyIcon,
  ArrowTrendingUpIcon,
  CalendarIcon,
  DocumentTextIcon,
  EyeIcon,
  ChevronLeftIcon,
  ChevronRightIcon,
  CheckCircleIcon,
  XCircleIcon,
  MicrophoneIcon,
  SparklesIcon,
  ArrowPathIcon,
  LightBulbIcon,
  BookOpenIcon,
  ChatBubbleLeftRightIcon,
  StarIcon
} from "@heroicons/react/24/outline";

interface AnswerDetail {
  questionId: string;
  questionTitle: string;
  questionCategory: string;
  questionDifficulty: string;
  userAnswer: string;
  result: string;
  score: number;
  criteriaScores?: {
    accuracy: number;
    completeness: number;
    clarity: number;
    examples: number;
    communication: number;
  };
  confidenceScore?: number;
  feedback: string;
  improvement: string;
  followUpQuestions?: string[];
}

interface InterviewResult {
  _id: string;
  sessionId: string;
  sessionTitle: string;
  date: string;
  duration: number;
  totalQuestions: number;
  answeredQuestions: number;
  overallScore: number;
  status: "completed" | "in-progress" | "abandoned";
  category: string;
  difficulty: string;
  strengths: string[];
  improvements: string[];
  feedback: string;
  avgConfidence?: number;
  categoryAnalysis?: Array<{
    category: string;
    score: number;
    feedback: string;
  }>;
  recommendedResources?: string[];
  nextSteps?: string[];
  confidenceAssessment?: string;
  answers?: AnswerDetail[];
}

interface FilterState {
  timeRange: "week" | "month" | "year" | "all";
  minScore: number;
  status: "all" | "completed" | "in-progress";
  search: string;
  category: string;
}

interface PaginationState {
  page: number;
  limit: number;
  total: number;
  totalPages: number;
}

const timeRanges = [
  { value: "week", label: "Last 7 Days" },
  { value: "month", label: "Last 30 Days" },
  { value: "year", label: "Last Year" },
  { value: "all", label: "All Time" }
];

const categories = ["All", "Technical", "Behavioral", "HR", "System Design", "DSA", "Mixed"];

export default function ResultsPage() {
  const router = useRouter();
  const [results, setResults] = useState<InterviewResult[]>([]);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    totalInterviews: 0,
    averageScore: 0,
    bestScore: 0,
    improvementRate: 0,
    totalQuestionsAnswered: 0,
    averageConfidence: 0
  });
  const [filters, setFilters] = useState<FilterState>({
    timeRange: "all",
    minScore: 0,
    status: "all",
    search: "",
    category: "All"
  });
  const [pagination, setPagination] = useState<PaginationState>({
    page: 1,
    limit: 10,
    total: 0,
    totalPages: 0
  });
  const [selectedResult, setSelectedResult] = useState<InterviewResult | null>(null);
  const [showModal, setShowModal] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [expandedAnswers, setExpandedAnswers] = useState<Set<string>>(new Set());

  // Review Modal state
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [currentSessionId, setCurrentSessionId] = useState<string>("");

  useEffect(() => {
    fetchResults();
    fetchStats();
  }, [filters, pagination.page]);

  // ✅ Uses api instance (auto attaches token, 30s timeout)
  const fetchResults = async () => {
    setLoading(true);
    try {
      const queryParams = new URLSearchParams({
        page: pagination.page.toString(),
        limit: pagination.limit.toString(),
        timeRange: filters.timeRange,
        minScore: filters.minScore.toString(),
        status: filters.status,
        ...(filters.search && { search: filters.search })
      });

      const res = await api.get(`/api/practice/results?${queryParams}`);
      const data = res.data;
      if (data.success) {
        setResults(data.data.results);
        setPagination(prev => ({
          ...prev,
          total: data.data.pagination.total,
          totalPages: data.data.pagination.totalPages
        }));
      }
    } catch (error) {
      console.error("Error fetching results:", error);
    } finally {
      setLoading(false);
    }
  };

  // ✅ Uses api instance (auto attaches token, 30s timeout)
  const fetchStats = async () => {
    try {
      const res = await api.get(`/api/dashboard/stats`);
      const data = res.data;
      if (data.success) {
        setStats({
          totalInterviews: data.data.totalInterviews || 0,
          averageScore: data.data.averageScore || 0,
          bestScore: data.data.bestScore || 0,
          improvementRate: data.data.improvementRate || 0,
          totalQuestionsAnswered: data.data.questionsAnswered || 0,
          averageConfidence: data.data.averageConfidence || 0
        });
      }
    } catch (error) {
      console.error("Error fetching stats:", error);
    }
  };

  const handleFilterChange = (key: keyof FilterState, value: any) => {
    setFilters(prev => ({ ...prev, [key]: value }));
    setPagination(prev => ({ ...prev, page: 1 }));
  };

  const clearFilters = () => {
    setFilters({
      timeRange: "all",
      minScore: 0,
      status: "all",
      search: "",
      category: "All"
    });
    setPagination(prev => ({ ...prev, page: 1 }));
  };

  const handlePageChange = (newPage: number) => {
    if (newPage >= 1 && newPage <= pagination.totalPages) {
      setPagination(prev => ({ ...prev, page: newPage }));
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return "text-green-400";
    if (score >= 60) return "text-yellow-400";
    return "text-red-400";
  };

  const formatDate = (dateString: string) => {
    if (!dateString) return "N/A";
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return "N/A";

    const now = new Date();
    const diffDays = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24));

    if (diffDays === 0) return "Today";
    if (diffDays === 1) return "Yesterday";
    if (diffDays < 7 && diffDays > 1) return `${diffDays} days ago`;
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return { icon: CheckCircleIcon, text: "Completed", color: "text-green-400 bg-green-400/10" };
      case "in-progress":
        return { icon: ArrowPathIcon, text: "In Progress", color: "text-yellow-400 bg-yellow-400/10" };
      default:
        return { icon: XCircleIcon, text: "Abandoned", color: "text-red-400 bg-red-400/10" };
    }
  };

  const toggleAnswerExpand = (answerId: string) => {
    const newExpanded = new Set(expandedAnswers);
    if (newExpanded.has(answerId)) {
      newExpanded.delete(answerId);
    } else {
      newExpanded.add(answerId);
    }
    setExpandedAnswers(newExpanded);
  };

  const getCriteriaLabel = (key: string) => {
    const labels: Record<string, string> = {
      accuracy: "Technical Accuracy",
      completeness: "Completeness",
      clarity: "Clarity & Structure",
      examples: "Real-world Examples",
      communication: "Communication",
    };
    return labels[key] || key;
  };

  const handleLeaveReview = (sessionId: string) => {
    setCurrentSessionId(sessionId);
    setShowReviewModal(true);
  };

  return (
    <div className="min-h-screen p-6">
      {/* Header */}
      <div className="mb-8">
        <h1 className="font-heading text-3xl font-extrabold text-[#FFF5F2] mb-2">
          Interview Results
        </h1>
        <p className="text-[#9aabb8] font-body">
          Track your progress and analyze your interview performance
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 mb-8">
        <div className="p-6 rounded-2xl border border-[#2a3a4a] bg-[#1B2838]">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[#9aabb8] text-sm">Total Interviews</span>
            <DocumentTextIcon className="h-5 w-5 text-[#FF6B6B]" />
          </div>
          <div className="font-heading text-3xl font-bold text-[#FFF5F2]">
            {stats.totalInterviews}
          </div>
          <div className="text-[#9aabb8] text-xs mt-2">Completed sessions</div>
        </div>

        <div className="p-6 rounded-2xl border border-[#2a3a4a] bg-[#1B2838]">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[#9aabb8] text-sm">Average Score</span>
            <ChartBarIcon className="h-5 w-5 text-[#FF6B6B]" />
          </div>
          <div className={`font-heading text-3xl font-bold ${getScoreColor(stats.averageScore)}`}>
            {stats.averageScore}%
          </div>
          <div className="text-[#9aabb8] text-xs mt-2">Across all interviews</div>
        </div>

        <div className="p-6 rounded-2xl border border-[#2a3a4a] bg-[#1B2838]">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[#9aabb8] text-sm">Best Score</span>
            <TrophyIcon className="h-5 w-5 text-yellow-400" />
          </div>
          <div className="font-heading text-3xl font-bold text-yellow-400">
            {stats.bestScore}%
          </div>
          <div className="text-[#9aabb8] text-xs mt-2">Your personal best</div>
        </div>

        <div className="p-6 rounded-2xl border border-[#2a3a4a] bg-[#1B2838]">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[#9aabb8] text-sm">Avg Confidence</span>
            <ChatBubbleLeftRightIcon className="h-5 w-5 text-[#6EE7B7]" />
          </div>
          <div className="font-heading text-3xl font-bold text-[#6EE7B7]">
            {stats.averageConfidence}%
          </div>
          <div className="text-[#9aabb8] text-xs mt-2">Confidence score</div>
        </div>

        <div className="p-6 rounded-2xl border border-[#2a3a4a] bg-[#1B2838]">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[#9aabb8] text-sm">Improvement</span>
            <ArrowTrendingUpIcon className={`h-5 w-5 ${stats.improvementRate >= 0 ? 'text-green-400' : 'text-red-400'}`} />
          </div>
          <div className={`font-heading text-3xl font-bold ${stats.improvementRate >= 0 ? 'text-green-400' : 'text-red-400'}`}>
            {stats.improvementRate >= 0 ? '+' : ''}{stats.improvementRate}%
          </div>
          <div className="text-[#9aabb8] text-xs mt-2">vs last month</div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="mb-6">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <input
              type="text"
              placeholder="Search by session title..."
              value={filters.search}
              onChange={(e) => handleFilterChange("search", e.target.value)}
              className="w-full pl-4 pr-4 py-3 rounded-xl bg-[#1B2838] border border-[#2a3a4a] text-[#FFF5F2] placeholder-[#4a5a6a] focus:border-[#FF6B6B]/40 outline-none transition-colors"
            />
          </div>

          <button
            onClick={() => setShowFilters(!showFilters)}
            className="md:hidden px-4 py-3 rounded-xl bg-[#1B2838] border border-[#2a3a4a] text-[#9aabb8] flex items-center justify-center gap-2"
          >
            <ChartBarIcon className="h-5 w-5" />
            Filters
          </button>
        </div>

        <div className={`mt-4 ${showFilters ? 'block' : 'hidden md:block'}`}>
          <div className="flex flex-wrap gap-4">
            <div className="flex gap-2">
              {timeRanges.map((range) => (
                <button
                  key={range.value}
                  onClick={() => handleFilterChange("timeRange", range.value)}
                  className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${filters.timeRange === range.value
                      ? "bg-[#FF6B6B] text-[#0D1B2A]"
                      : "bg-[#1B2838] text-[#9aabb8] hover:text-[#FFF5F2] border border-[#2a3a4a]"
                    }`}
                >
                  {range.label}
                </button>
              ))}
            </div>

            <div className="flex gap-2">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => handleFilterChange("category", cat)}
                  className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${filters.category === cat
                      ? "bg-[#FF6B6B] text-[#0D1B2A]"
                      : "bg-[#1B2838] text-[#9aabb8] hover:text-[#FFF5F2] border border-[#2a3a4a]"
                    }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            <div className="flex gap-2">
              {["all", "completed", "in-progress"].map((s) => (
                <button
                  key={s}
                  onClick={() => handleFilterChange("status", s)}
                  className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${filters.status === s
                      ? "bg-[#FF6B6B] text-[#0D1B2A]"
                      : "bg-[#1B2838] text-[#9aabb8] hover:text-[#FFF5F2] border border-[#2a3a4a]"
                    }`}
                >
                  {s === "all" ? "All" : s === "completed" ? "Completed" : "In Progress"}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-3">
              <span className="text-[#9aabb8] text-sm">Min Score:</span>
              <select
                value={filters.minScore}
                onChange={(e) => handleFilterChange("minScore", parseInt(e.target.value))}
                className="px-3 py-1.5 rounded-lg bg-[#1B2838] border border-[#2a3a4a] text-[#FFF5F2] text-sm focus:border-[#FF6B6B]/40 outline-none"
              >
                <option value={0}>Any</option>
                <option value={70}>70%+</option>
                <option value={80}>80%+</option>
                <option value={90}>90%+</option>
              </select>
            </div>

            {(filters.timeRange !== "all" || filters.minScore !== 0 || filters.status !== "all" || filters.search || filters.category !== "All") && (
              <button
                onClick={clearFilters}
                className="px-3 py-1.5 rounded-lg text-sm text-[#FF6B6B] hover:bg-[#FF6B6B]/10 transition-all"
              >
                Clear all
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Results List */}
      {loading ? (
        <div className="flex items-center justify-center py-20">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#FF6B6B]"></div>
        </div>
      ) : results.length === 0 ? (
        <div className="text-center py-20">
          <DocumentTextIcon className="h-16 w-16 text-[#2a3a4a] mx-auto mb-4" />
          <p className="text-[#9aabb8] font-body text-lg">No results found</p>
          <p className="text-[#9aabb8] text-sm mt-2">Complete some practice sessions to see your results here</p>
          <button
            onClick={() => router.push('/dashboard/practice')}
            className="mt-4 px-4 py-2 rounded-xl bg-[#FF6B6B] text-[#0D1B2A] text-sm font-bold hover:bg-[#FFA07A] transition-all"
          >
            Start Practicing
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {results.map((result) => {
            const StatusIcon = getStatusBadge(result.status).icon;
            const statusStyle = getStatusBadge(result.status).color;
            const isCompleted = result.status === "completed";

            return (
              <div
                key={result._id}
                className="group p-6 rounded-2xl border border-[#2a3a4a] bg-[#1B2838] hover:border-[#FF6B6B]/40 hover:bg-[#FF6B6B]/5 transition-all cursor-pointer"
                onClick={() => {
                  setSelectedResult(result);
                  setShowModal(true);
                }}
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2 flex-wrap">
                      <h3 className="font-heading font-bold text-lg text-[#FFF5F2] group-hover:text-[#FF6B6B] transition-colors">
                        {result.sessionTitle}
                      </h3>
                      <span className={`px-2 py-1 rounded-lg text-xs font-mono flex items-center gap-1 ${statusStyle}`}>
                        <StatusIcon className="h-3 w-3" />
                        {getStatusBadge(result.status).text}
                      </span>
                      <span className="px-2 py-1 rounded-lg text-xs font-mono bg-[#FF6B6B]/10 text-[#FF6B6B]">
                        {result.category}
                      </span>
                    </div>
                    <div className="flex flex-wrap gap-4 text-sm text-[#9aabb8]">
                      <div className="flex items-center gap-1">
                        <CalendarIcon className="h-4 w-4" />
                        <span>{formatDate(result.date)}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <ClockIcon className="h-4 w-4" />
                        <span>{result.duration} min</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <MicrophoneIcon className="h-4 w-4" />
                        <span>{result.answeredQuestions}/{result.totalQuestions} answered</span>
                      </div>
                      {result.avgConfidence && (
                        <div className="flex items-center gap-1">
                          <ChatBubbleLeftRightIcon className="h-4 w-4" />
                          <span>Confidence: {result.avgConfidence}/10</span>
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className={`text-3xl font-heading font-bold ${getScoreColor(result.overallScore)}`}>
                      {result.overallScore}%
                    </div>
                    <div className="text-[#9aabb8] text-xs mt-1">Overall Score</div>
                  </div>
                </div>

                {result.strengths && result.strengths.length > 0 && (
                  <div className="flex flex-wrap gap-2 mt-3 pt-3 border-t border-[#2a3a4a]">
                    {result.strengths.slice(0, 2).map((strength, idx) => (
                      <span key={idx} className="text-xs text-green-400">✓ {strength}</span>
                    ))}
                    {result.strengths.length > 2 && (
                      <span className="text-xs text-[#9aabb8]">+{result.strengths.length - 2} more</span>
                    )}
                  </div>
                )}

                {isCompleted && (
                  <div className="mt-4 flex items-center justify-end gap-3">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleLeaveReview(result._id);
                      }}
                      className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#FF6B6B]/10 border border-[#FF6B6B]/20 text-[#FF6B6B] text-sm font-medium hover:bg-[#FF6B6B]/20 transition-all"
                    >
                      <StarIcon className="h-4 w-4" />
                      Leave a Review
                    </button>
                    <EyeIcon className="h-4 w-4 text-[#4a5a6a] group-hover:text-[#FF6B6B] transition-colors" />
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Pagination */}
      {pagination.totalPages > 1 && (
        <div className="mt-8 flex items-center justify-center gap-2">
          <button
            onClick={() => handlePageChange(pagination.page - 1)}
            disabled={pagination.page === 1}
            className="p-2 rounded-lg border border-[#2a3a4a] text-[#9aabb8] hover:border-[#FF6B6B] hover:text-[#FF6B6B] disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            <ChevronLeftIcon className="h-5 w-5" />
          </button>

          <div className="flex gap-2">
            {Array.from({ length: Math.min(5, pagination.totalPages) }, (_, i) => {
              let pageNum;
              if (pagination.totalPages <= 5) {
                pageNum = i + 1;
              } else if (pagination.page <= 3) {
                pageNum = i + 1;
              } else if (pagination.page >= pagination.totalPages - 2) {
                pageNum = pagination.totalPages - 4 + i;
              } else {
                pageNum = pagination.page - 2 + i;
              }
              return (
                <button
                  key={pageNum}
                  onClick={() => handlePageChange(pageNum)}
                  className={`min-w-[36px] h-9 rounded-lg text-sm font-medium transition-all ${pagination.page === pageNum
                      ? "bg-[#FF6B6B] text-[#0D1B2A]"
                      : "border border-[#2a3a4a] text-[#9aabb8] hover:border-[#FF6B6B] hover:text-[#FF6B6B]"
                    }`}
                >
                  {pageNum}
                </button>
              );
            })}
          </div>

          <button
            onClick={() => handlePageChange(pagination.page + 1)}
            disabled={pagination.page === pagination.totalPages}
            className="p-2 rounded-lg border border-[#2a3a4a] text-[#9aabb8] hover:border-[#FF6B6B] hover:text-[#FF6B6B] disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            <ChevronRightIcon className="h-5 w-5" />
          </button>
        </div>
      )}

      {/* Result Detail Modal */}
      {showModal && selectedResult && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="relative max-w-4xl w-full max-h-[90vh] overflow-y-auto rounded-2xl bg-[#1B2838] border border-[#2a3a4a] shadow-2xl">
            <div className="sticky top-0 bg-[#1B2838] border-b border-[#2a3a4a] p-6">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2 flex-wrap">
                    <h2 className="font-heading text-xl font-bold text-[#FFF5F2]">
                      {selectedResult.sessionTitle}
                    </h2>
                    <span className={`px-2 py-1 rounded-lg text-xs font-mono flex items-center gap-1 ${getStatusBadge(selectedResult.status).color}`}>
                      <CheckCircleIcon className="h-3 w-3" />
                      {getStatusBadge(selectedResult.status).text}
                    </span>
                  </div>
                  <div className="flex gap-4 text-sm text-[#9aabb8] flex-wrap">
                    <div className="flex items-center gap-1">
                      <CalendarIcon className="h-4 w-4" />
                      <span>{formatDate(selectedResult.date)}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <ClockIcon className="h-4 w-4" />
                      <span>{selectedResult.duration} minutes</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <BookOpenIcon className="h-4 w-4" />
                      <span>{selectedResult.category}</span>
                    </div>
                  </div>
                </div>
                <button
                  onClick={() => setShowModal(false)}
                  className="p-2 rounded-lg hover:bg-white/5 text-[#9aabb8] hover:text-[#FF6B6B] transition-colors"
                >
                  <XCircleIcon className="h-6 w-6" />
                </button>
              </div>
            </div>

            <div className="p-6 space-y-6">
              <div className="text-center p-6 rounded-2xl bg-gradient-to-br from-[#FF6B6B]/10 to-transparent border border-[#FF6B6B]/20">
                <div className={`text-6xl font-heading font-bold ${getScoreColor(selectedResult.overallScore)} mb-2`}>
                  {selectedResult.overallScore}%
                </div>
                <p className="text-[#9aabb8]">Overall Performance Score</p>
              </div>

              {selectedResult.strengths && selectedResult.strengths.length > 0 && (
                <div>
                  <h3 className="font-heading font-bold text-green-400 mb-3 flex items-center gap-2">
                    <CheckCircleIcon className="h-5 w-5" />
                    Key Strengths
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {selectedResult.strengths.map((strength, idx) => (
                      <span key={idx} className="px-3 py-1.5 rounded-lg bg-green-400/10 border border-green-400/20 text-green-400 text-sm">
                        {strength}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {selectedResult.improvements && selectedResult.improvements.length > 0 && (
                <div>
                  <h3 className="font-heading font-bold text-yellow-400 mb-3 flex items-center gap-2">
                    <ArrowTrendingUpIcon className="h-5 w-5" />
                    Areas for Improvement
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {selectedResult.improvements.map((improvement, idx) => (
                      <span key={idx} className="px-3 py-1.5 rounded-lg bg-yellow-400/10 border border-yellow-400/20 text-yellow-400 text-sm">
                        {improvement}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              <div>
                <h3 className="font-heading font-bold text-[#FF6B6B] mb-3 flex items-center gap-2">
                  <SparklesIcon className="h-5 w-5" />
                  AI Coach Feedback
                </h3>
                <div className="p-4 rounded-xl bg-[#0D1B2A] border border-[#2a3a4a]">
                  <p className="text-[#9aabb8] leading-relaxed">
                    {selectedResult.feedback}
                  </p>
                </div>
              </div>

              {selectedResult.status === "completed" && (
                <div className="pt-4 border-t border-[#2a3a4a]">
                  <button
                    onClick={() => {
                      setShowModal(false);
                      handleLeaveReview(selectedResult._id);
                    }}
                    className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-[#FF6B6B]/10 border border-[#FF6B6B]/20 text-[#FF6B6B] font-heading font-bold hover:bg-[#FF6B6B]/20 transition-all"
                  >
                    <StarIcon className="h-5 w-5" />
                    Share Your Experience
                  </button>
                </div>
              )}

              <div className="flex gap-3 pt-4">
                <button
                  onClick={() => {
                    setShowModal(false);
                    router.push(`/dashboard/practice`);
                  }}
                  className="flex-1 py-3 rounded-xl bg-[#FF6B6B] text-[#0D1B2A] font-heading font-bold hover:bg-[#FFA07A] transition-all"
                >
                  Practice Again
                </button>
                <button
                  onClick={() => setShowModal(false)}
                  className="px-6 py-3 rounded-xl border border-[#2a3a4a] text-[#9aabb8] hover:text-[#FFF5F2] transition-colors"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Review Modal */}
      <ReviewModal
        isOpen={showReviewModal}
        onClose={() => {
          setShowReviewModal(false);
          setCurrentSessionId("");
        }}
        sessionId={currentSessionId}
        onSubmitSuccess={() => {
          console.log("Review submitted successfully!");
        }}
      />
    </div>
  );
}