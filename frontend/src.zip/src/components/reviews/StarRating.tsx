'use client';

import { useState } from 'react';

interface StarRatingProps {
  rating: number;
  onRatingChange?: (rating: number) => void;
  readonly?: boolean;
  size?: number;
  showLabel?: boolean;
  label?: string;
}

export default function StarRating({ 
  rating, 
  onRatingChange, 
  readonly = false,
  size = 24,
  showLabel = false,
  label = 'Rating'
}: StarRatingProps) {
  const [hoverRating, setHoverRating] = useState(0);

  const displayRating = hoverRating || rating;

  return (
    <div className="flex flex-col gap-2">
      {showLabel && (
        <label className="text-sm font-medium text-gray-700">
          {label}
        </label>
      )}
      <div className="flex gap-1 items-center">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            type="button"
            onClick={() => !readonly && onRatingChange?.(star)}
            onMouseEnter={() => !readonly && setHoverRating(star)}
            onMouseLeave={() => !readonly && setHoverRating(0)}
            disabled={readonly}
            className={`focus:outline-none transition-all ${
              !readonly && 'hover:scale-110 cursor-pointer'
            } disabled:cursor-default`}
            style={{ fontSize: `${size}px` }}
            aria-label={`Rate ${star} stars out of 5`}
          >
            <span className={star <= displayRating ? 'text-yellow-400' : 'text-gray-300'}>
              ★
            </span>
          </button>
        ))}
        
        {!readonly && rating > 0 && (
          <span className="ml-2 text-sm text-gray-600">
            {rating}.0/5.0
          </span>
        )}
      </div>
      
      {!readonly && hoverRating > 0 && (
        <div className="text-xs text-gray-500">
          {hoverRating === 1 && 'Poor'}
          {hoverRating === 2 && 'Fair'}
          {hoverRating === 3 && 'Good'}
          {hoverRating === 4 && 'Very Good'}
          {hoverRating === 5 && 'Excellent'}
        </div>
      )}
    </div>
  );
}