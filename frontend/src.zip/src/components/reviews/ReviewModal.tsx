'use client';

import { useState } from 'react';
import StarRating from './StarRating';

interface ReviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  sessionId: string;
  onSubmitSuccess?: () => void;
}

export default function ReviewModal({ 
  isOpen, 
  onClose, 
  sessionId, 
  onSubmitSuccess 
}: ReviewModalProps) {
  const [formData, setFormData] = useState({
    rating: 5,
    message: '',
    role: 'Student',
    company: '',
    name: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [charCount, setCharCount] = useState(0);
  const [error, setError] = useState('');

  const roles = ['Student', 'Graduate', 'Developer', 'Senior Developer', 'Tech Lead', 'Other'];

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError('');

    const token = localStorage.getItem('token');
    if (!token) {
      setError('Please login to submit a review');
      setIsSubmitting(false);
      return;
    }

    try {
      // ✅ Use env variable if available, fallback to hardcoded
      const BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000';
      // Ensure we have the /api prefix
      const API_URL = BASE_URL.endsWith('/api') ? BASE_URL : `${BASE_URL}/api`;
      
      console.log('📡 Submitting review to:', `${API_URL}/reviews`);
      console.log('📝 Session ID:', sessionId);
      console.log('📦 Review data:', formData);
      
      const response = await fetch(`${API_URL}/reviews`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          sessionId,
          ...formData
        })
      });

      // Check if response is JSON
      const contentType = response.headers.get('content-type');
      if (!contentType || !contentType.includes('application/json')) {
        const text = await response.text();
        console.error('Non-JSON response:', text.substring(0, 200));
        throw new Error('Server returned an error. Make sure backend is running on port 5000');
      }

      const data = await response.json();

      if (data.success) {
        setSubmitted(true);
        setTimeout(() => {
          onClose();
          if (onSubmitSuccess) onSubmitSuccess();
        }, 2000);
      } else {
        setError(data.message || 'Failed to submit review');
      }
    } catch (err) {
      console.error('Review submission error:', err);
      setError('Unable to submit review. Please make sure the backend server is running on http://localhost:5000');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (submitted) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-2xl max-w-md w-full p-8 text-center">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <span className="text-4xl">✓</span>
          </div>
          <h3 className="text-2xl font-bold mb-2">Thank You!</h3>
          <p className="text-gray-600">
            Your review has been submitted and will appear after admin approval.
          </p>
          <button
            onClick={onClose}
            className="mt-4 px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl">
        <div className="sticky top-0 bg-white border-b px-6 py-4 flex justify-between items-center">
          <div>
            <h2 className="text-2xl font-bold">Share Your Experience</h2>
            <p className="text-gray-500 text-sm mt-1">Help others improve their interview skills</p>
          </div>
          <button 
            onClick={onClose} 
            className="p-2 hover:bg-gray-100 rounded-full transition-colors text-gray-500 hover:text-gray-700"
          >
            <span className="text-2xl">×</span>
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Error Message */}
          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-3 flex items-center gap-2 text-red-700">
              <span className="text-lg">⚠️</span>
              <span className="text-sm">{error}</span>
            </div>
          )}

          {/* Rating */}
          <div className="text-center">
            <label className="block text-sm font-medium text-gray-700 mb-3">
              How would you rate your experience?
            </label>
            <StarRating 
              rating={formData.rating} 
              onRatingChange={(r) => setFormData({...formData, rating: r})}
              size={32}
            />
          </div>

          {/* Review Message */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Your Review <span className="text-red-500">*</span>
            </label>
            <textarea
              required
              rows={4}
              maxLength={500}
              value={formData.message}
              onChange={(e) => {
                setFormData({...formData, message: e.target.value});
                setCharCount(e.target.value.length);
              }}
              placeholder="Share your experience with the AI interview platform. What did you like? How did it help you?"
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
            />
            <div className="flex justify-between text-sm mt-1">
              <span className="text-gray-500">Minimum 10 characters</span>
              <span className={charCount > 450 ? 'text-orange-500' : 'text-gray-500'}>
                {charCount}/500 characters
              </span>
            </div>
          </div>

          {/* Role & Company */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Your Role <span className="text-red-500">*</span>
              </label>
              <select
                required
                value={formData.role}
                onChange={(e) => setFormData({...formData, role: e.target.value})}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              >
                {roles.map(role => (
                  <option key={role} value={role}>{role}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Company (Optional)
              </label>
              <input
                type="text"
                value={formData.company}
                onChange={(e) => setFormData({...formData, company: e.target.value})}
                placeholder="e.g., Google, Microsoft, Startup"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          {/* Name */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Your Name (Optional)
            </label>
            <input
              type="text"
              value={formData.name}
              onChange={(e) => setFormData({...formData, name: e.target.value})}
              placeholder="Will be displayed with your review"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            />
            <p className="text-xs text-gray-500 mt-1">
              Leave blank to remain anonymous
            </p>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={isSubmitting || formData.message.length < 10}
            className="w-full bg-gradient-to-r from-blue-600 to-blue-700 text-white py-3 rounded-xl font-semibold hover:from-blue-700 hover:to-blue-800 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-lg"
          >
            {isSubmitting ? 'Submitting...' : 'Submit Review'}
          </button>

          <p className="text-xs text-gray-500 text-center">
            Your review helps others make informed decisions. All reviews are moderated for quality.
          </p>
        </form>
      </div>
    </div>
  );
}