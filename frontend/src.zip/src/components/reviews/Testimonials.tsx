'use client';

import { useState, useEffect } from 'react';
import StarRating from './StarRating';

interface Review {
  _id: string;
  name: string;
  role: string;
  company?: string;
  rating: number;
  message: string;
  createdAt: string;
}

export default function Testimonials() {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [stats, setStats] = useState<{ averageRating: number; totalReviews: number } | null>(null);
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(0);

  useEffect(() => {
    fetchReviews();
  }, []);

  const fetchReviews = async () => {
    try {
      const BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000';
      const API_URL = BASE_URL.endsWith('/api') ? BASE_URL : `${BASE_URL}/api`;
      
      const response = await fetch(`${API_URL}/reviews/approved?page=1&limit=9`);
      const data = await response.json();
      
      if (data.success) {
        setReviews(data.data.reviews);
        setStats(data.data.stats);
      }
    } catch (error) {
      console.error('Failed to fetch reviews:', error);
    } finally {
      setLoading(false);
    }
  };

  const itemsPerPage = 3;
  const totalPages = Math.ceil(reviews.length / itemsPerPage);
  const displayedReviews = reviews.slice(
    currentPage * itemsPerPage,
    (currentPage + 1) * itemsPerPage
  );

  const getInitials = (name: string) => {
    if (!name) return 'U';
    return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
  };

  if (loading) {
    return (
      <div className="py-20 bg-gradient-to-b from-gray-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          </div>
        </div>
      </div>
    );
  }

  if (reviews.length === 0) return null;

  return (
    <section className="py-20 bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Trusted by Students & Professionals
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Join thousands of successful candidates who landed their dream jobs
          </p>
          
          {stats && stats.totalReviews > 0 && (
            <div className="flex items-center justify-center gap-8 mt-6 flex-wrap">
              <div className="flex items-center gap-3">
                <div className="flex gap-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <span key={star} className="text-2xl text-yellow-400">★</span>
                  ))}
                </div>
                <div>
                  <span className="text-3xl font-bold text-gray-900">{stats.averageRating}</span>
                  <span className="text-gray-600"> out of 5</span>
                </div>
              </div>
              <div className="text-gray-600 text-lg">
                Based on <span className="font-semibold text-gray-900">{stats.totalReviews}</span> reviews
              </div>
            </div>
          )}
        </div>

        {/* Testimonials Grid */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          {displayedReviews.map((review, index) => (
            <div 
              key={review._id} 
              className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-100"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="flex items-start gap-4 mb-4">
                {/* Avatar */}
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white font-semibold text-lg shadow-md">
                  {getInitials(review.name)}
                </div>
                
                <div className="flex-1">
                  <h4 className="font-semibold text-lg">{review.name || 'Anonymous User'}</h4>
                  <div className="flex items-center gap-2 text-sm text-gray-500">
                    <span>{review.role}</span>
                    {review.company && (
                      <>
                        <span>•</span>
                        <span>{review.company}</span>
                      </>
                    )}
                  </div>
                </div>
                
                <span className="text-3xl text-gray-200">"</span>
              </div>

              {/* Rating */}
              <div className="mb-3">
                <StarRating rating={review.rating} readonly={true} size={16} />
              </div>

              {/* Message */}
              <p className="text-gray-600 leading-relaxed">
                "{review.message}"
              </p>

              {/* Date */}
              <p className="text-xs text-gray-400 mt-4 pt-2 border-t">
                {new Date(review.createdAt).toLocaleDateString('en-US', { 
                  month: 'long', 
                  year: 'numeric' 
                })}
              </p>
            </div>
          ))}
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex justify-center gap-3 mt-8">
            <button
              onClick={() => setCurrentPage(p => Math.max(0, p - 1))}
              disabled={currentPage === 0}
              className="px-4 py-2 rounded-lg border border-gray-300 disabled:opacity-50 hover:bg-gray-100 transition-colors"
            >
              Previous
            </button>
            <div className="flex gap-2">
              {[...Array(totalPages)].map((_, i) => (
                <button
                  key={i}
                  onClick={() => setCurrentPage(i)}
                  className={`w-10 h-10 rounded-lg transition-colors ${
                    currentPage === i
                      ? 'bg-blue-600 text-white'
                      : 'border border-gray-300 hover:bg-gray-100'
                  }`}
                >
                  {i + 1}
                </button>
              ))}
            </div>
            <button
              onClick={() => setCurrentPage(p => Math.min(totalPages - 1, p + 1))}
              disabled={currentPage === totalPages - 1}
              className="px-4 py-2 rounded-lg border border-gray-300 disabled:opacity-50 hover:bg-gray-100 transition-colors"
            >
              Next
            </button>
          </div>
        )}
      </div>
    </section>
  );
}